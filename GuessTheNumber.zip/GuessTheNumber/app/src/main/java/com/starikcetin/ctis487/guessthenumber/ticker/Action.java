package com.starikcetin.ctis487.guessthenumber.ticker;

public interface Action {
    void perform();
}
