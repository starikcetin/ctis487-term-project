package com.starikcetin.ctis487.guessthenumber.eventbus;

public class Event {
    public final Object sender;

    public Event(Object sender) {
        this.sender = sender;
    }
}
