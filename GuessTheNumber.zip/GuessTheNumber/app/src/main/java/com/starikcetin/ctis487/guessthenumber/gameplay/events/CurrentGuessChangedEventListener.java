package com.starikcetin.ctis487.guessthenumber.gameplay.events;

import com.starikcetin.ctis487.guessthenumber.eventbus.EventListener;

public interface CurrentGuessChangedEventListener extends EventListener<CurrentGuessChangedEvent> {
}
